﻿using Newtonsoft.Json;
using ServerSide.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Mvc;

namespace ServerSide.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult SendMailAsync()
        {
            return View();
        }


        [HttpPost]
        public async System.Threading.Tasks.Task<ActionResult> SendMailAsync(EmailModel emailModel)
        {
            string baseUrl = Request.Url.Scheme + "://" + Request.Url.Authority +
    Request.ApplicationPath.TrimEnd('/') + "/";

            EmailAPIModel emailAPIModel = new EmailAPIModel();

            emailAPIModel.subject = emailModel.subject;
            emailAPIModel.content = emailModel.content;

            emailAPIModel.sender = new Sender();
            emailAPIModel.sender.emailAddress = emailModel.sender;

            emailAPIModel.recipients = new List<Recipient>();
            if (!string.IsNullOrEmpty(emailModel.RecipientsTO))
            {
                foreach (var item in emailModel.RecipientsTO.Split(','))
                {
                    emailAPIModel.recipients.Add(
                        new Recipient
                        {
                            emailAddress = item.Trim(),
                            recipientType = "TO",
                        });
                }
            }

            using (var content = new MultipartFormDataContent())
            {
                HttpClient httpClient = new HttpClient();

                var json = JsonConvert.SerializeObject(emailAPIModel);
                var stringContent = new StringContent(json);

                //NOTE: convert this JSON object to the required model at the backend side
                content.Add(new StringContent(json), "mail");
                //NOTE: convert this JSON object to the required model at the backend side

                foreach (var item in emailModel.Files)
                {
                    if (item != null)
                    {
                        //content.Headers.Remove("Content-Type");
                        //content.Headers.TryAddWithoutValidation("Content-Type", "multipart/form-data;");
                        content.Add(CreateFileContent(item.InputStream, item.FileName, item.ContentType), "mail");
                    }
                }

                //NOTE: change this with you API end point
                //var response = await httpClient.PostAsync("/mails/send?userID=" + emailModel.UserId, content);
                //NOTE: change this with you API end point

                var response = await httpClient.PostAsync(baseUrl + "/api/values", content);

                var result = response.EnsureSuccessStatusCode();
            }

            return RedirectToAction("SendMailAsync");
        }

        public ActionResult ApprovalAsync()
        {
            return View();
        }

        [HttpPost]
        public async System.Threading.Tasks.Task<ActionResult> ApprovalPostAsync()
        {
            string baseUrl = Request.Url.Scheme + "://" + Request.Url.Authority +
    Request.ApplicationPath.TrimEnd('/') + "/";

            var httpPostedFile = Request.Files;
            var data = httpPostedFile.Count;
            var fdata = Request.Form;
            var json = fdata["obj"];

            using (var content = new MultipartFormDataContent())
            {
                HttpClient httpClient = new HttpClient();

                var stringContent = new StringContent(json);

                //NOTE: convert this JSON object to the required model at the backend side
                content.Add(new StringContent(json), "approval");
                //NOTE: convert this JSON object to the required model at the backend side

                foreach (var item in httpPostedFile)
                {
                    HttpPostedFileBase file = Request.Files[item.ToString()];
                    if (file != null)
                    {
                        content.Add(CreateFileContent(file.InputStream, file.FileName, file.ContentType));
                    }
                }

                //NOTE: change this with you API end point
                //var response = await httpClient.PostAsync("/mails/send?userID=" + emailModel.UserId, content);
                //NOTE: change this with you API end point

                var response = await httpClient.PostAsync(baseUrl + "/api/values", content);

                var result = response.EnsureSuccessStatusCode();
            }

            return RedirectToAction("ApprovalAsync");
        }

        private StreamContent CreateFileContent(Stream stream, string fileName, string contentType)
        {
            var fileContent = new StreamContent(stream);
            fileContent.Headers.ContentDisposition = new ContentDispositionHeaderValue("form-data")
            {
                Name = "\"files\"",
                FileName = "\"" + fileName + "\""
            };
            fileContent.Headers.ContentType = new MediaTypeHeaderValue(contentType);
            return fileContent;
        }
    }
}
